# BizChat Pro — Pack production Mali

Ce pack prépare l'architecture de production pour:
- authentification Firebase
- chat Firestore
- catalogue et commandes
- notifications FCM
- paiements Orange Money et Moov Money
- paiement à la livraison
- sécurité côté serveur

Important: les identifiants/API marchands ne sont pas inclus. Ils doivent être obtenus auprès des opérateurs.
