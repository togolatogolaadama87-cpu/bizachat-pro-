# BizChat Pro — compilation depuis un téléphone

1. Crée un dépôt GitHub vide.
2. Téléverse le contenu de ce dossier dans la branche `main`.
3. Ouvre l'onglet **Actions**.
4. Sélectionne **Build BizChat Pro Android**.
5. Appuie sur **Run workflow**.
6. Après la fin du workflow, ouvre l'exécution puis **Artifacts**.
7. Télécharge `bizchat-pro-apk` pour l'installation Android.
8. Télécharge `bizchat-pro-aab` pour Google Play.

Important:
- Le workflow génère les fichiers Android manquants avec `flutter create`.
- `firebase_options.dart` doit être configuré pour ton propre projet Firebase avant un usage réel.
- Les clés Orange Money/Moov Money ne doivent jamais être mises dans GitHub ou dans Flutter.
- Pour une publication réelle, il faut aussi une signature Android de production et une configuration Firebase/Google Play adaptées.
