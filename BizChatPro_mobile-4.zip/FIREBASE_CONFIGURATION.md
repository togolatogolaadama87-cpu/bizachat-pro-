# Configuration Firebase

Le projet contient une structure Firebase, mais les identifiants de ton projet ne doivent pas être inventés.

Sur une machine disposant de FlutterFire CLI, exécuter:
`flutterfire configure`

Le fichier `lib/firebase_options.dart` doit alors être généré pour ton projet Firebase.

Ne partage jamais avec moi:
- mot de passe Google
- clé privée de service account
- secrets Orange Money
- secrets Moov Money
