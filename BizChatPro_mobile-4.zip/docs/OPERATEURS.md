# Accès opérateurs

Orange Money: l'API Web Payment est officiellement disponible au Mali pour les marchands Orange Money. L'accès nécessite une souscription/validation marchand.

Moov Money: le site officiel de Moov Africa Malitel présente le paiement marchand SANI. Pour une intégration applicative, obtenir directement auprès de Moov les modalités/API disponibles pour le compte marchand.

Ne jamais utiliser de faux endpoints, faux tokens ou faux numéros de marchand en production.
