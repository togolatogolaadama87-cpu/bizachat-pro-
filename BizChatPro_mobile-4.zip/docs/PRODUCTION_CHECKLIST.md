# Checklist BizChat Pro

## Application
- [ ] Firebase project production
- [ ] flutterfire configure
- [ ] Auth email/téléphone
- [ ] profils professionnels
- [ ] conversations/messages
- [ ] médias Storage
- [ ] FCM
- [ ] catalogue Firestore
- [ ] panier/commandes
- [ ] statuts commande
- [ ] statistiques
- [ ] suppression de compte
- [ ] politique de confidentialité
- [ ] conditions d'utilisation

## Paiements Mali
- [ ] compte marchand Orange Money
- [ ] accès Orange Money Web Payment/API
- [ ] compte marchand Moov Money
- [ ] documentation/API ou mécanisme marchand fourni par Moov
- [ ] tests sandbox/test opérateur
- [ ] callback/webhook sécurisé
- [ ] vérification serveur
- [ ] idempotence des transactions
- [ ] journal d'audit
- [ ] remboursement/annulation selon les capacités du fournisseur

## Sécurité
- [ ] aucun secret dans Flutter
- [ ] secrets dans Secret Manager
- [ ] règles Firestore revues
- [ ] règles Storage revues
- [ ] App Check
- [ ] rate limiting
- [ ] sauvegardes
- [ ] Crashlytics/logging
- [ ] tests d'autorisation

## Publication
- [ ] compte Google Play Console
- [ ] signature release/AAB
- [ ] icône et captures
- [ ] fiche Play Store
- [ ] politique de confidentialité accessible
- [ ] tests internes/fermés
- [ ] conformité Play
