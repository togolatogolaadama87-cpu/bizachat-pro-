# BizChat Pro — checklist production

## Déjà structuré
- Application Flutter
- Firebase Auth/Firestore/Storage/FCM dépendances
- Modèles produits
- Service catalogue
- Service commandes
- Écrans catalogue/commandes/stats/automatisation
- Règles Firestore de départ

## À connecter avant publication
- `flutterfire configure`
- Projet Firebase réel
- règles Firestore finalisées et testées
- Cloud Storage rules
- Cloud Functions FCM
- authentification téléphone/SMS
- lecteur/enregistreur audio complet
- appels WebRTC
- paiement Mobile Money avec un prestataire choisi
- abonnements Google Play
- IA avec backend sécurisé
- politique de confidentialité
- suppression de compte et export des données
- tests Android/iOS
- signature AAB
- compte Google Play Console

## Important
Ce ZIP est une base technique intégrée, pas une application commerciale déjà publiée. Les services externes nécessitent tes propres comptes, identifiants et vérifications.
