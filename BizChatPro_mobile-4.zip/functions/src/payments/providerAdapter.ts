// Interface unique pour brancher les fournisseurs après réception des accès marchands.
export type PaymentStart = {
  orderId: string;
  amountXof: number;
  customerPhone?: string;
  callbackUrl?: string;
};

export type ProviderResult = {
  providerReference: string;
  redirectUrl?: string;
  status: 'processing' | 'paid' | 'failed';
};

export interface PaymentProvider {
  startPayment(input: PaymentStart): Promise<ProviderResult>;
  verifyPayment(providerReference: string): Promise<ProviderResult>;
}

// Implémentations Orange/Moov à ajouter uniquement avec la documentation,
// les endpoints et identifiants officiels fournis par chaque opérateur.
