import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

const db = admin.firestore();

export const getPaymentStatus = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Connexion requise');
  const paymentId = String(data.paymentId || '');
  const snap = await db.doc(`payments/${paymentId}`).get();
  if (!snap.exists) throw new functions.https.HttpsError('not-found', 'Paiement introuvable');
  const p = snap.data()!;
  if (p.userId !== context.auth.uid) throw new functions.https.HttpsError('permission-denied', 'Non autorisé');
  return { paymentId, status: p.status, providerReference: p.providerReference ?? null };
});
