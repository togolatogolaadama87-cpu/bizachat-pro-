import * as functions from 'firebase-functions';
import * as admin from 'firebase-admin';

const db = admin.firestore();

export const startPayment = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new functions.https.HttpsError('unauthenticated', 'Connexion requise');

  const orderId = String(data.orderId || '');
  const amountXof = Number(data.amountXof || 0);
  const method = String(data.method || '');

  if (!orderId || !Number.isInteger(amountXof) || amountXof <= 0) {
    throw new functions.https.HttpsError('invalid-argument', 'Commande ou montant invalide');
  }
  if (!['orangeMoney', 'moovMoney', 'cashOnDelivery'].includes(method)) {
    throw new functions.https.HttpsError('invalid-argument', 'Moyen de paiement invalide');
  }

  const orderRef = db.doc(`orders/${orderId}`);
  const order = await orderRef.get();
  if (!order.exists) throw new functions.https.HttpsError('not-found', 'Commande introuvable');
  if (order.data()?.userId !== context.auth.uid) {
    throw new functions.https.HttpsError('permission-denied', 'Commande non autorisée');
  }

  const paymentRef = db.collection('payments').doc();
  await paymentRef.set({
    orderId,
    userId: context.auth.uid,
    amountXof,
    currency: 'XOF',
    method,
    status: method === 'cashOnDelivery' ? 'pending' : 'processing',
    providerReference: null,
    createdAt: admin.firestore.FieldValue.serverTimestamp(),
    updatedAt: admin.firestore.FieldValue.serverTimestamp(),
  });

  // TODO production: appeler ici le connecteur sécurisé de l'opérateur.
  // Les secrets doivent rester dans Secret Manager / variables serveur.
  return { paymentId: paymentRef.id, status: method === 'cashOnDelivery' ? 'pending' : 'processing' };
});
