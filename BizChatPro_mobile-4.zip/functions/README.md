Cloud Functions à implémenter pour la production :
1. Déclencher une notification FCM lors d'un nouveau message.
2. Mettre à jour les compteurs/statistiques.
3. Vérifier les paiements via les APIs officielles du fournisseur choisi.
4. Valider les changements de statut de commande côté serveur.
5. Traiter les tâches IA sans exposer de clé secrète dans l'application.
6. Nettoyer les médias et données supprimés.

Les clés privées/API ne doivent jamais être intégrées dans Flutter.
