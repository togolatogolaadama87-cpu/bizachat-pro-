import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'firebase_options.dart';
import 'screens/app_shell.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const BizChatApp());
}

class BizChatApp extends StatelessWidget {
  const BizChatApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'BizChat Pro',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: const Color(0xFF0A9F63)),
    home: const AppShell(),
  );
}
