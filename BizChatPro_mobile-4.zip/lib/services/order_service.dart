import 'package:cloud_firestore/cloud_firestore.dart';

class OrderService {
  final db=FirebaseFirestore.instance;
  Future<String> createOrder({
    required String businessId, required String customerId,
    required List<Map<String,dynamic>> items, required double total,
  }) async {
    final ref=await db.collection('businesses').doc(businessId).collection('orders').add({
      'customerId':customerId,'items':items,'total':total,'currency':'XOF',
      'status':'new','paymentStatus':'pending','createdAt':FieldValue.serverTimestamp(),
    });
    return ref.id;
  }

  Stream<QuerySnapshot<Map<String,dynamic>>> orders(String businessId)=>
    db.collection('businesses').doc(businessId).collection('orders')
      .orderBy('createdAt',descending:true).snapshots();

  Future<void> setStatus(String businessId,String orderId,String status)=>
    db.collection('businesses').doc(businessId).collection('orders').doc(orderId).update({'status':status});
}
