import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class CatalogService {
  final db=FirebaseFirestore.instance;
  Stream<List<Product>> products(String businessId)=>db.collection('businesses').doc(businessId).collection('products')
    .orderBy('createdAt',descending:true).snapshots().map((s)=>s.docs.map((d)=>Product.fromMap(d.id,d.data())).toList());

  Future<void> addProduct(String businessId, Product p)=>db.collection('businesses').doc(businessId).collection('products').add({
    ...p.toMap(),'createdAt':FieldValue.serverTimestamp(),
  });

  Future<void> updateStock(String businessId,String productId,int stock)=>db.collection('businesses').doc(businessId).collection('products').doc(productId).update({'stock':stock});
}
