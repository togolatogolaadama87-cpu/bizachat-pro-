class Product {
  final String id, name, description, currency;
  final double price;
  final int stock;
  Product({required this.id, required this.name, required this.description, required this.price, required this.stock, this.currency='XOF'});
  Map<String,dynamic> toMap()=>{'name':name,'description':description,'price':price,'stock':stock,'currency':currency};
  factory Product.fromMap(String id, Map<String,dynamic> m)=>Product(
    id:id,name:'${m['name']??''}',description:'${m['description']??''}',
    price:(m['price']??0).toDouble(),stock:(m['stock']??0) as int,currency:'${m['currency']??'XOF'}');
}
