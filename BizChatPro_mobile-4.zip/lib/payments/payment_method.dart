enum PaymentMethod { orangeMoney, moovMoney, cashOnDelivery }

extension PaymentMethodX on PaymentMethod {
  String get label => switch (this) {
    PaymentMethod.orangeMoney => 'Orange Money',
    PaymentMethod.moovMoney => 'Moov Money',
    PaymentMethod.cashOnDelivery => 'Paiement à la livraison',
  };
}
