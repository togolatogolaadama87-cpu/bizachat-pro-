import 'package:cloud_functions/cloud_functions.dart';
import 'payment_method.dart';

class PaymentGateway {
  final FirebaseFunctions functions;
  PaymentGateway({FirebaseFunctions? functions})
      : functions = functions ?? FirebaseFunctions.instance;

  Future<Map<String, dynamic>> start({
    required String orderId,
    required int amountXof,
    required PaymentMethod method,
  }) async {
    final result = await functions.httpsCallable('startPayment').call({
      'orderId': orderId,
      'amountXof': amountXof,
      'method': method.name,
    });
    return Map<String, dynamic>.from(result.data as Map);
  }

  Future<Map<String, dynamic>> status(String paymentId) async {
    final result = await functions.httpsCallable('getPaymentStatus').call({
      'paymentId': paymentId,
    });
    return Map<String, dynamic>.from(result.data as Map);
  }
}
