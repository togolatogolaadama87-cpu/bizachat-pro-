import 'package:flutter/material.dart';
class ChatPlaceholder extends StatelessWidget{
 const ChatPlaceholder({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('BizChat Pro',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
  const SizedBox(height:8),const Text('Messagerie temps réel, médias et appels.'),
  const SizedBox(height:20),TextField(decoration:InputDecoration(hintText:'Rechercher',prefixIcon:Icon(Icons.search),filled:true,border:OutlineInputBorder())),
  const SizedBox(height:20),const Card(child:ListTile(leading:CircleAvatar(child:Icon(Icons.person)),title:Text('Vos conversations'),subtitle:Text('Connectez Firebase pour charger les conversations.'))),
 ]);
}
