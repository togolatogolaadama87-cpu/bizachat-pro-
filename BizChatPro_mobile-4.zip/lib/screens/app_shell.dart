import 'package:flutter/material.dart';
import 'catalog_page.dart';
import 'orders_page.dart';
import 'automation_page.dart';
import 'dashboard_page.dart';
import 'chat_placeholder.dart';

class AppShell extends StatefulWidget {
  const AppShell({super.key});
  @override State<AppShell> createState()=>_AppShellState();
}
class _AppShellState extends State<AppShell>{
  int i=0;
  final pages=const [ChatPlaceholder(),CatalogPage(),OrdersPage(),DashboardPage(),AutomationPage()];
  @override Widget build(BuildContext context)=>Scaffold(
    body:SafeArea(child:pages[i]),
    bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const[
      NavigationDestination(icon:Icon(Icons.chat_outlined),selectedIcon:Icon(Icons.chat),label:'Chats'),
      NavigationDestination(icon:Icon(Icons.storefront_outlined),selectedIcon:Icon(Icons.storefront),label:'Catalogue'),
      NavigationDestination(icon:Icon(Icons.shopping_bag_outlined),selectedIcon:Icon(Icons.shopping_bag),label:'Commandes'),
      NavigationDestination(icon:Icon(Icons.analytics_outlined),selectedIcon:Icon(Icons.analytics),label:'Stats'),
      NavigationDestination(icon:Icon(Icons.auto_awesome_outlined),selectedIcon:Icon(Icons.auto_awesome),label:'Automatisation'),
    ]),
  );
}
