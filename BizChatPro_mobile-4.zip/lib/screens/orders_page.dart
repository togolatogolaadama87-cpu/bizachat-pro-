import 'package:flutter/material.dart';
class OrdersPage extends StatelessWidget{const OrdersPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Commandes',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
  const SizedBox(height:12),
  ...[['#1001','Nouvelle','15 000 FCFA'],['#1000','Préparée','25 000 FCFA'],['#0999','Livrée','8 500 FCFA']].map((o)=>Card(child:ListTile(
   leading:const Icon(Icons.shopping_bag),title:Text(o[0]),subtitle:Text(o[1]),trailing:Text(o[2],style:const TextStyle(fontWeight:FontWeight.bold)),
  ))),
 ]);
}
