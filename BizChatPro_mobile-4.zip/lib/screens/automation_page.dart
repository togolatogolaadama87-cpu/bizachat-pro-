import 'package:flutter/material.dart';
class AutomationPage extends StatefulWidget{const AutomationPage({super.key});@override State<AutomationPage> createState()=>_AutomationPageState();}
class _AutomationPageState extends State<AutomationPage>{
 bool welcome=true,away=false,quick=true,ai=false;
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Automatisation',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
  SwitchListTile(title:const Text('Message d’accueil'),value:welcome,onChanged:(v)=>setState(()=>welcome=v)),
  SwitchListTile(title:const Text('Message d’absence'),value:away,onChanged:(v)=>setState(()=>away=v)),
  SwitchListTile(title:const Text('Réponses rapides'),value:quick,onChanged:(v)=>setState(()=>quick=v)),
  SwitchListTile(title:const Text('Assistant IA'),value:ai,onChanged:(v)=>setState(()=>ai=v)),
  const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('L’IA devra être reliée à un fournisseur de modèle et à des règles de sécurité avant production.'))),
 ]);
}
