import 'package:flutter/material.dart';
class DashboardPage extends StatelessWidget{const DashboardPage({super.key});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(18),children:[
  const Text('Tableau de bord',style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)),
  const SizedBox(height:15),
  const Card(child:ListTile(leading:Icon(Icons.people),title:Text('Clients'),trailing:Text('0'))),
  const Card(child:ListTile(leading:Icon(Icons.chat),title:Text('Messages'),trailing:Text('0'))),
  const Card(child:ListTile(leading:Icon(Icons.payments),title:Text('Ventes'),trailing:Text('0 FCFA'))),
  const Card(child:ListTile(leading:Icon(Icons.shopping_cart),title:Text('Commandes'),trailing:Text('0'))),
 ]);
}
