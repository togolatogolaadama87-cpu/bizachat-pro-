import 'package:flutter/material.dart';
class CatalogPage extends StatefulWidget{const CatalogPage({super.key});@override State<CatalogPage> createState()=>_CatalogPageState();}
class _CatalogPageState extends State<CatalogPage>{
 final items=[['Sac de maïs','7500'],['Aliment volaille','12500'],['Poussins','500']];
 @override Widget build(BuildContext context)=>Scaffold(
  appBar:AppBar(title:const Text('Catalogue'),actions:[IconButton(onPressed:(){},icon:const Icon(Icons.add))]),
  body:ListView(padding:const EdgeInsets.all(12),children:items.map((p)=>Card(child:ListTile(
   leading:const Icon(Icons.inventory_2_outlined,size:35),title:Text(p[0]),subtitle:Text('${p[1]} FCFA'),trailing:const Icon(Icons.chevron_right),
  ))).toList()),
 );
}
